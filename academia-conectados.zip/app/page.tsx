import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <main className="p-6 space-y-8">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Academia Conectados</h1>
        <p className="text-lg">Una academia virtual para adultos mayores que desean aprender habilidades digitales básicas.</p>
        <Button className="text-lg">Inscribirse</Button>
      </section>

      <section className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-4 space-y-2">
            <h2 className="text-xl font-semibold">Clases de WhatsApp</h2>
            <p>Aprende a enviar mensajes, fotos y hacer videollamadas.</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 space-y-2">
            <h2 className="text-xl font-semibold">Uso de Smartphone</h2>
            <p>Descubre cómo navegar tu celular con confianza y seguridad.</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 space-y-2">
            <h2 className="text-xl font-semibold">Redes Sociales</h2>
            <p>Aprende a usar Facebook, Instagram y compartir con tus seres queridos.</p>
          </CardContent>
        </Card>
      </section>

      <section className="bg-gray-100 p-6 rounded-2xl shadow-md">
        <h2 className="text-2xl font-bold mb-4">¿Por qué elegirnos?</h2>
        <ul className="list-disc pl-6 space-y-2 text-lg">
          <li>Clases paso a paso adaptadas para adultos mayores</li>
          <li>Acceso 100% virtual desde casa</li>
          <li>Paciencia, cariño y mucha práctica</li>
        </ul>
      </section>
    </main>
  );
}
