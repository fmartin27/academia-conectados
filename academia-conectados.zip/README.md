# Academia Conectados

Academia virtual para adultos mayores que desean aprender tecnología desde casa.